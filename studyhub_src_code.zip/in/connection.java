/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studyhub.in;




/**
 *
 * @author hhhhhhhhhp
 */
public class connection {
       


 public static void main(String[] args) {
        // TODO code application logic here
        
        Loading_Screen l =new Loading_Screen();
          l.setVisible(true);
          connection m= new connection();
     
    
                try 
                  {
                for(int x=0;x<=100;x++)
                      {
              Thread.sleep(110);
              l.jprogress.setText(Integer.toString(x)+"%");
              l.jbar.setValue(x);
            
                 if(x==100)
                     {
                   l.setVisible(false);
                 
            
                     }
                     }
                   } 
                 catch (Exception e) 
                 {
                 }
                
        LoginPage LoginFrame = new LoginPage();
        LoginFrame.setVisible(true);
        LoginFrame.pack();
        LoginFrame.setLocationRelativeTo(null);
                
    }

}
