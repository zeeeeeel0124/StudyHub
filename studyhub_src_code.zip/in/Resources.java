/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package studyhub.in;

import com.myapp.session.UserSession;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.URI;
import java.sql.*;
import java.util.Vector;
import javax.swing.plaf.basic.BasicInternalFrameUI;


/**
 *
 * @author hhhhhhhhhp
 */
public class Resources extends javax.swing.JInternalFrame {
    private  String loggedInUsername;
    /**
     * Creates new form Resources
     */
    public Resources(String loggedInUsername) {
        initComponents();
        this.setBorder(javax.swing.BorderFactory.createEmptyBorder(0,0,0,0));
        BasicInternalFrameUI ui = (BasicInternalFrameUI)this.getUI();
        ui.setNorthPane(null);
        configureTable();
        UpdateTb();
    }

    
    
   private void configureTable() {
        DefaultTableModel model = new DefaultTableModel(new Object[]{"Course Name", "Instructor", "Link"}, 0);
        coursesTable.setModel(model);

        // Set the custom renderer for the Link column
        coursesTable.getColumnModel().getColumn(2).setCellRenderer(new LinkRenderer());

        // Set column widths: adjust the "Link" column to accommodate long URLs
        coursesTable.getColumnModel().getColumn(0).setPreferredWidth(200);  // Course Name column
        coursesTable.getColumnModel().getColumn(1).setPreferredWidth(150);  // Instructor column
        coursesTable.getColumnModel().getColumn(2).setPreferredWidth(500);  // Link column

        // Set the table row height to accommodate wrapping
        coursesTable.setRowHeight(30);
        coursesTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);  // Disable auto-resizing to allow wrapping

        // Add mouse listener for clicking on links
        coursesTable.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = coursesTable.getSelectedRow();
                int col = coursesTable.getSelectedColumn();
                if (col == 2) { // Check if it's the "Link" column
                    String url = (String) coursesTable.getValueAt(row, col);
                    openLink(url);
                }
            }
        });
    }

    // Open the URL when a link is clicked
    private void openLink(String url) {
        try {
            Desktop.getDesktop().browse(new java.net.URI(url));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Failed to open link: " + e.getMessage());
        }
    }

    // Update the table with course data from the database
    private void UpdateTb() {
    DefaultTableModel model = (DefaultTableModel) coursesTable.getModel();
    model.setRowCount(0); // Clear existing rows

    try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/studyhub_db", "root", "")) {
        // Retrieve the logged-in instructor's username
        String loggedInUsername = UserSession.getUsername();
        
        // Query to retrieve only the courses added by the logged-in instructor
        String query = "SELECT course_name, instructor, link FROM courses WHERE instructor = ?";
        PreparedStatement pst = con.prepareStatement(query);
        pst.setString(1, loggedInUsername); // Bind the logged-in instructor's username
        
        ResultSet rs = pst.executeQuery();

        while (rs.next()) {
            Vector<String> row = new Vector<>();
            row.add(rs.getString("course_name"));
            row.add(rs.getString("instructor"));
            row.add(rs.getString("link"));
            model.addRow(row);
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Failed to load courses: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}
    
     private void addCourse() {
    String courseName = course_get.getText();
    String link = link_get.getText();
    String instructor = instruc_get.getText();

    // Check if fields are empty
    if (courseName.isEmpty() || link.isEmpty() || instructor.isEmpty()) {
        JOptionPane.showMessageDialog(this, "All fields are required!", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Validate URL format
    if (!isValidURL(link)) {
        JOptionPane.showMessageDialog(this, "Invalid URL format!", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Insert course details into the database
    try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/studyhub_db", "root", "")) {
        String query = "INSERT INTO courses (course_name, link, instructor) VALUES (?, ?, ?)";
        PreparedStatement pst = con.prepareStatement(query);
        pst.setString(1, courseName);
        pst.setString(2, link);
        pst.setString(3, instructor);
        pst.executeUpdate();

        JOptionPane.showMessageDialog(this, "Course added successfully!");
        UpdateTb(); // Refresh table
        course_get.setText("");
        link_get.setText("");
        instruc_get.setText("");

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}

     
     // Check if the provided URL is valid
    private boolean isValidURL(String url) {
    try {
        new java.net.URI(url);  // Try creating a URI object to validate
        return true;
    } catch (Exception e) {
        return false;  // Invalid URL
    }
}

    


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        course_get = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        link_get = new javax.swing.JTextField();
        instruc_get = new javax.swing.JTextField();
        ADDButton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        coursesTable = new javax.swing.JTable();
        deleteButton = new javax.swing.JButton();

        jPanel2.setBackground(new java.awt.Color(162, 210, 255));
        jPanel2.setPreferredSize(new java.awt.Dimension(724, 378));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel4.setText("INSTRUCTOR");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setText("STUDENT COURSE");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setText("LINK");

        ADDButton.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        ADDButton.setText("ADD");
        ADDButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ADDButtonActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("MATERIALS");

        coursesTable.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        coursesTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "COURSE ", "INSTRUCTOR", "LINK"
            }
        ));
        coursesTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                coursesTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(coursesTable);

        jScrollPane2.setViewportView(jScrollPane1);

        deleteButton.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        deleteButton.setText("DELETE");
        deleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(deleteButton)
                .addGap(349, 349, 349))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(ADDButton, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(325, 325, 325))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3))
                        .addGap(43, 43, 43)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(course_get)
                            .addComponent(instruc_get)
                            .addComponent(link_get, javax.swing.GroupLayout.PREFERRED_SIZE, 334, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(331, 331, 331)
                        .addComponent(jLabel1))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 781, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(24, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(deleteButton)
                .addGap(13, 13, 13)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel3))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(course_get, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(instruc_get, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(link_get, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ADDButton)
                .addContainerGap(35, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 817, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 435, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ADDButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ADDButtonActionPerformed
       addCourse();
    }//GEN-LAST:event_ADDButtonActionPerformed

    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButtonActionPerformed
       int selectedRow = coursesTable.getSelectedRow(); // Get the selected row from the table
        if (selectedRow >= 0) {
        // Retrieve the course name (or course ID) from the selected row
        String courseName = (String) coursesTable.getValueAt(selectedRow, 0); // Assuming course name is in the first column
        String link = (String) coursesTable.getValueAt(selectedRow, 2); // Assuming link is in the third column

        // Confirm deletion
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete the course: " + courseName + "?", "Delete Course", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/studyhub_db", "root", "")) {
                // SQL query to delete the course from the database
                String query = "DELETE FROM courses WHERE course_name = ? AND link = ?";
                PreparedStatement pst = con.prepareStatement(query);
                pst.setString(1, courseName);
                pst.setString(2, link);
                int rowsAffected = pst.executeUpdate();

                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(this, "Course deleted successfully!");
                    UpdateTb();  // Refresh the table after deletion
                } else {
                    JOptionPane.showMessageDialog(this, "Course not found in the database.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error deleting course: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    } else {
        JOptionPane.showMessageDialog(this, "Please select a course to delete.", "Error", JOptionPane.ERROR_MESSAGE);
    }


    }//GEN-LAST:event_deleteButtonActionPerformed

    private void coursesTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_coursesTableMouseClicked
        int row = coursesTable.getSelectedRow();
        int column = coursesTable.getSelectedColumn();

        // If the clicked column is the "Link" column, open the link
        if (column == 2) {
            String url = (String) coursesTable.getValueAt(row, column);
            try {
                Desktop.getDesktop().browse(new URI(url));
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(Resources.this, "Failed to open link: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }

    }//GEN-LAST:event_coursesTableMouseClicked

    

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ADDButton;
    private javax.swing.JTextField course_get;
    private javax.swing.JTable coursesTable;
    private javax.swing.JButton deleteButton;
    private javax.swing.JTextField instruc_get;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField link_get;
    // End of variables declaration//GEN-END:variables
}
