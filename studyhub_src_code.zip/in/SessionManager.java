/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studyhub.in;

/**
 *
 * @author hhhhhhhhhp
 */
public class SessionManager {
   private static String loggedInUsername;
   private static String studentUsername;

    public static void setLoggedInUsername(String username) {
        loggedInUsername = username;
        System.out.println("Username set to: " + loggedInUsername); // Debugging line
        
    }

    public static String getLoggedInUsername() {
        System.out.println("Retrieving username: " + loggedInUsername); 
        return loggedInUsername;
        
    }
    public static String getStudentUsername() {
        return studentUsername;
    }
    
}

