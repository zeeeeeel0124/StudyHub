/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studyhub.in;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import studyhub.in.MyCourses;


public class CourseDAO {
    private Connection connection;
    
    // Constructor to establish database connection
    public CourseDAO() {
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/studyhub_db", "root", ""); // Update credentials
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Failed to connect to the database!");
        }
    }
    
    // Add a new course to the database
    public boolean addCourse(int courseId, String courseName, String courseDescription, String instructor) {
        String query = "INSERT INTO courses (course_id, course_name, course_description, instructor) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, courseId);
            stmt.setString(2, courseName);
            stmt.setString(3, courseDescription);
            stmt.setString(4, instructor);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    // Fetch all courses and return them as a list of rows
    public List<List<String>> getAllCourses() {
        List<List<String>> courses = new ArrayList<>();
        String query = "SELECT * FROM courses";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                List<String> courseRow = new ArrayList<>();
                courseRow.add(String.valueOf(rs.getInt("course_id")));
                courseRow.add(rs.getString("course_name"));
                courseRow.add(rs.getString("course_description"));
                courseRow.add(rs.getString("instructor"));
                courses.add(courseRow);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return courses;
    }
    // Update a course in the database
    public boolean updateCourse(int courseId, String courseName, String courseDescription, String instructor) {
        String query = "UPDATE courses SET course_name = ?, course_description = ?, instructor = ? WHERE course_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, courseName);
            stmt.setString(2, courseDescription);
            stmt.setString(3, instructor);
            stmt.setInt(4, courseId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
   // Delete a course from the database
    public boolean deleteCourse(int courseId) {
        String query = "DELETE FROM courses WHERE course_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, courseId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    
    
    
}
