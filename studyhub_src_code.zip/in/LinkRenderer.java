/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studyhub.in;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.awt.event.*;
import java.net.URI;


/**
 *
 * @author hhhhhhhhhp
 */
public class LinkRenderer extends DefaultTableCellRenderer {

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        
        super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

        // Use JTextArea for rendering the link to support line wrapping
        JTextArea textArea = new JTextArea();
        textArea.setText((String) value); 
        textArea.setWrapStyleWord(true);   
        textArea.setLineWrap(true);        
        textArea.setOpaque(false);         
        textArea.setEditable(false);       
        textArea.setFocusable(false);     
        textArea.setBackground(table.getBackground()); // Match the background color of the table
        textArea.setFont(getFont());       

        // Set the link text color to blue and make it underlined
        textArea.setForeground(Color.BLUE);
        textArea.setText("" + textArea.getText() + ""); 

        // Adjust the row height if needed for wrapping
        table.setRowHeight(row, 60); 

        // Add mouse listener to open the link when clicked
        textArea.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                try {
                    // Check if the link is clicked
                    URI uri = new URI(textArea.getText().replace("", "").replace("", ""));
                    Desktop.getDesktop().browse(uri);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(table, "Failed to open link: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        
        return textArea;
    }
}
